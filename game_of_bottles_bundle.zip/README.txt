# Game of Bottles - Awakening Engine v1.0

This is a text-based RPG framework with dual layers: an outer fantasy adventure and an inner awakening arc.

## Files
- game_of_bottles_v1.txt: The full instructions for the AI model to run the game.

## Usage
Upload `game_of_bottles_v1.txt` into an AI chat window and follow the instructions.

---
Key: "awake" (used for encryption/decryption if needed)
